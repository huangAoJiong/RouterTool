默认web管理
ip:192.168.33.1
name:jie
pass:125125jj
wifi
ID：MI-4Cjie
pass:123456700